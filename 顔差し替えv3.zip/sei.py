﻿import dlib
import cv2

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

frame = cv2.imread("aa.jpg")
# ここに処理を追加していく ----
dets = detector(frame[:, :, ::-1])
if len(dets) > 0:
    parts = predictor(frame, dets[0]).parts()

    # 確認用 ---
    img = frame * 0
    for i in parts:
        cv2.circle(img, (i.x, i.y), 3, (255, 0, 0), -1)

    cv2.imshow("me", img)

    nose = parts[33].y - parts[27].y
    print("鼻 %d" %nose)
    # 確認用 ここまで ---

# ここまで ----

cv2.waitKey(0)
cv2.destroyAllWindows()
